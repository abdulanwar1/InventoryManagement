package com.example.demo;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;
/**

 The Mainview class is the controller for the main view of the application.

 It initializes the view and handles user actions, such as adding, deleting, and modifying parts and products.
 It handles user input and updates the UI to display the inventory of parts and products.
 */
public class Mainscreencontroller implements Initializable {
    public Label MainLabel;
    public Button ExitButton;
    public Button AddPartsButton;
    public TextField SearchField;
    public TableView<Part>MainPartsTableView;
   /* public TableColumn<Part,Integer>IDColumn;
    public TableColumn<Part,String>NameColumn;
    public TableColumn<Part,Integer>InventoryColumn;
    public TableColumn<Part,Double>PriceColumn;*/
    public TextField MainProductsSearchField;
    public TableView<Product> MainProductsTableView;
    public TableColumn ProductIDColumn;
    public TableColumn ProductNameColumn;
    public TableColumn ProductInventoryColumn;
    public TableColumn ProductPriceColumn;
    public TableColumn IDColumn;
    public TableColumn NameColumn;
    public TableColumn InventoryColumn;
    public TableColumn PriceColumn;
    private ObservableList<Part> parts;
    private ObservableList<Product> products;

    @FXML
    private AnchorPane AnchorPane;

    /**

     Handles the Add Parts button click event. Opens the Add Part form.
     @param event The button click event.
     @throws IOException If an I/O error occurs.
     */
    @FXML
    private void AddPartsClick(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("Addpart.fxml"));
        Parent root = loader.load();
        Scene scene = new Scene(root);
        Stage stage = (Stage) ((Node)event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }
    /**

     Handles the Delete Parts button click event. Deletes the selected part from the parts list and updates the TableView.

     @param event The button click event.
     */
    @FXML
    private void DeletePartsClick(ActionEvent event) {
        // Get the selected part from the TableView
        Part selectedPart = (Part) MainPartsTableView.getSelectionModel().getSelectedItem();

        if (selectedPart == null) {
            // Display an error message if no part is selected
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText("No part selected");
            alert.setContentText("Please select a part to delete.");
            alert.showAndWait();
        } else {
            // Confirm the deletion with the user
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Confirm Deletion");
            alert.setHeaderText("Are you sure you want to delete the selected part?");
            alert.setContentText("This action cannot be undone.");

            Optional<ButtonType> result = alert.showAndWait();

            if (result.isPresent() && result.get() == ButtonType.OK) {
                // Remove the selected part from the list of parts
                parts.remove(selectedPart);

                // Update the TableView
                MainPartsTableView.setItems(parts);
            }
        }
    }
    /**

     Handles the Modify Parts button click event. Opens the Modify Part form with the selected part's data.
     @param event The button click event.
     @throws IOException If an I/O error occurs.
     */
/*    @FXML
    void ModifyPartsClick(ActionEvent event) throws IOException {
        // Get the selected part from the table view
        if (NullPointerException e) {
            // No part is selected, show an error message
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText(null);
            alert.setContentText("Please select a part to modify.");
            alert.showAndWait();
        } else {
            // A part is selected, open the Modify Part form and pass the selected part to it
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/demo/Mainview.fxml"));
            loader.load();
            Modifypart controller = loader.getController();
            loader.setController(controller);
            Parent root = loader.load();
            Stage stage = new Stage();
            stage.setTitle("Modify Part");
            stage.setScene(new Scene(root));
            stage.show();
        }
    }*/
    @FXML
    void ModifyPartsClick(ActionEvent event) throws IOException {
        if (MainPartsTableView.getSelectionModel().isEmpty()) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setContentText("Select a part first");
            alert.show();
        } else {
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("../views/ModifyPart.fxml"));
            loader.load();

            Modifypart Controller = loader.getController();

            Stage stage = (Stage) ((Button)event.getSource()).getScene().getWindow();
            Parent scene = loader.getRoot();
            stage.setScene(new Scene(scene));
            stage.show();
        }
    }

    /**

     Handles the click event for the search button in the parts view. Searches for parts that match the search term and updates the parts table view accordingly.
     If the search term is empty, displays all parts.
     If no parts are found with the search term, displays an alert.
     @param event the action event triggered by the search button click
     */
    @FXML
    private void PartsSearchClick(ActionEvent event) {
        String searchTerm = SearchField.getText();
        ObservableList<Part> matchingParts = FXCollections.observableArrayList();

        if (searchTerm.isEmpty()) {
            // If search term is empty, display all parts
            MainPartsTableView.setItems(Inventory.getAllParts());
        } else {
            // If search term is not empty, search for matching parts
            for (Part part : Inventory.getAllParts()) {
                if (Part.getName().contains(searchTerm) || Integer.toString(Part.getId()).contains(searchTerm)) {
                    matchingParts.add(part);
                }
            }
            if (!matchingParts.isEmpty()) {
                MainPartsTableView.setItems(matchingParts);
                IDColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
                NameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));
                InventoryColumn.setCellValueFactory(new PropertyValueFactory<>("stock"));
                PriceColumn.setCellValueFactory(new PropertyValueFactory<>("price"));
            } else {
                Alert alert = new Alert(AlertType.INFORMATION);
                alert.setTitle("No Parts Found");
                alert.setHeaderText(null);
                alert.setContentText("No parts found with the search term: " + searchTerm);
                alert.showAndWait();
            }
        }
    }
    /**

     Handles the Modify Products button click event.
     Opens the Modify Product form with the selected product from the table view.
     If no product is selected, an error message is displayed.
     @param event The event object generated by the click event.
     @throws IOException if the ModifyProduct.fxml file is not found.
     */
    @FXML
    void ModifyProductsClick(ActionEvent event) throws IOException {
// Get the selected product from the table view
        Product selectedProduct = (Product) MainProductsTableView.getSelectionModel().getSelectedItem();
        if (selectedProduct == null) {
// No product is selected, show an error message
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText(null);
            alert.setContentText("Please select a product to modify.");
            alert.showAndWait();
        } else {
// A product is selected, open the Modify Product form and pass the selected product to it
            FXMLLoader loader = new FXMLLoader(getClass().getResource("Modifyproduct.fxml"));
            Parent root = loader.load();
            Modifyproduct controller = loader.getController();
            controller.setProduct(selectedProduct);
            Stage stage = new Stage();
            stage.setTitle("Modify Product");
            stage.setScene(new Scene(root));
            stage.show();
        }
    }
    /**

     Called when the Delete Products button is clicked.
     Deletes the selected product from the table view after confirming with the user.
     Displays an error message if no product is selected.
     @param event The event triggered by clicking the Delete Products button.
     */


    @FXML
    void DeleteProductsClick(ActionEvent event) {
        Product selectedProduct = (Product) MainProductsTableView.getSelectionModel().getSelectedItem();
        if (selectedProduct == null) {
            // No product is selected, show an error message
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText(null);
            alert.setContentText("Please select a product to delete.");
            alert.showAndWait();
        } else {
            // Confirm the deletion
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Confirmation");
            alert.setHeaderText(null);
            alert.setContentText("Are you sure you want to delete the selected product?");
            Optional<ButtonType> result = alert.showAndWait();
            if (result.isPresent() && result.get() == ButtonType.OK) {
                // Delete the selected product
                products.remove(selectedProduct);
                MainProductsTableView.setItems(products);
            }
        }
    }
    /**

     Handles the action when the user clicks the search button to search for products.
     If the search term is empty, displays all products in the table view. Otherwise, searches for products
     whose name or ID contains the search term and displays the matching products in the table view.
     If no products match the search term, displays an information dialog box indicating that no products were found.
     @param event The ActionEvent object generated when the search button is clicked.
     */
    @FXML
    private void SearchProductsClick(ActionEvent event) {
        String searchTerm = MainProductsSearchField.getText().trim().toLowerCase();
        ObservableList<Product> matchingProducts = FXCollections.observableArrayList();

        if (searchTerm.isEmpty()) {
            // If search term is empty, display all products
            MainProductsTableView.setItems(Inventory.getAllProducts());
        } else {
            // If search term is not empty, search for matching products
            for (Product product : Inventory.getAllProducts()) {
                if (product.getName().toLowerCase().contains(searchTerm) || Integer.toString(product.getId()).contains(searchTerm)) {
                    matchingProducts.add(product);
                }
            }
            if (!matchingProducts.isEmpty()) {
                MainProductsTableView.setItems(matchingProducts);
            } else {
                Alert alert = new Alert(AlertType.INFORMATION);
                alert.setTitle("No Products Found");
                alert.setHeaderText(null);
                alert.setContentText("No products found with the search term: " + searchTerm);
                alert.showAndWait();
            }
        }
    }
    /**

     Handles the event when the "Add Products" button is clicked.
     Opens the "Add Products" window when the button is clicked.
     @param event the event triggered by clicking the "Add Products" button
     @throws IOException if an I/O exception occurs when loading the "Add Products" window
     */
    @FXML
    void AddProductsClick(ActionEvent event) throws IOException {

        Parent addProducts = FXMLLoader.load(getClass().getResource("AddProduct.fxml"));
        Scene scene = new Scene(addProducts);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        window.setScene(scene);
        window.show();
    }
    /**

     Handles the event when the user clicks the Exit button.
     Closes the application window and exits the application.
     @param event the event triggered by the user's click on the Exit button
     */
    @FXML
    private void ExitClick(ActionEvent event) {
        Platform.exit();
    }





    /**

     Initializes the Mainview class.

     This method is called by the FXMLLoader when loading the fxml file for the main screen.

     It initializes the parts and products table views with their respective data and property values.

     @param url The location of the fxml file.

     @param resourceBundle The resources used to localize the fxml file.
     */


    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        InHouse p1 = new InHouse(1,"tire",20.0,4,2,5,1);
        Inventory.addPart(p1);
        Outsourced p2 = new Outsourced(2,"seat",30.0,4,2,5,"honda");
        Inventory.addPart(p2);
        Product car1 = new Product(1,"toyota",2000.00,2,1,4);
        Inventory.addProduct(car1);
        Product car2 = new Product(2,"toy",2000.00,2,1,4);
        Inventory.addProduct(car2);

        for (Part part: Inventory.getAllParts()){
            System.out.println(part);
        }
        //Populate parts table view
        MainPartsTableView.setItems(Inventory.getAllParts());
        System.out.println(Inventory.getAllParts().size());
        IDColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
        NameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));
        InventoryColumn.setCellValueFactory(new PropertyValueFactory<>("stock"));
        PriceColumn.setCellValueFactory(new PropertyValueFactory<>("price"));

        //Populate products table view
        MainProductsTableView.setItems(Inventory.getAllProducts());
        ProductIDColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
        ProductNameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));
        ProductInventoryColumn.setCellValueFactory(new PropertyValueFactory<>("stock"));
        ProductPriceColumn.setCellValueFactory(new PropertyValueFactory<>("price"));

    }
}
