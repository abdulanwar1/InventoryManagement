package com.example.demo;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/**

 Represents a product that can be sold and contains associated parts.
 */
public class Product {

    private static final ObservableList<Part> associatedParts = FXCollections.observableArrayList();
    private int id;
    private String name;
    private double price;
    private int stock;
    private int min;
    private int max;

    /**
     Creates a new Product object.
     @param id the product ID
     @param name the name of the product
     @param price the price of the product
     @param stock the current inventory level of the product
     @param min the minimum inventory level of the product
     @param max the maximum inventory level of the product
     */
    public Product(int id, String name, double price, int stock, int min, int max) {
        this.id = id;
        this.name = name;
        this.price = price;
        this.stock = stock;
        this.min = min;
        this.max = max;
    }

    /**
     Sets the ID of the product.
     @param id the new ID to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     Sets the name of the product.
     @param name the new name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     Sets the price of the product.
     @param price the new price to set
     */
    public void setPrice(double price) {
        this.price = price;
    }

    /**
     Sets the current inventory level of the product.
     @param stock the new inventory level to set
     */
    public void setStock(int stock) {
        this.stock = stock;
    }

    /**
     Sets the minimum inventory level of the product.
     @param min the new minimum inventory level to set
     */
    public void setMin(int min) {
        this.min = min;
    }

    /**
     Sets the maximum inventory level of the product.
     @param max the new maximum inventory level to set
     */
    public void setMax(int max) {
        this.max = max;
    }

    /**
     Returns the ID of the product.
     @return the ID of the product
     */
    public int getId() {
        return id;
    }

    /**
     Returns the name of the product.
     @return the name of the product
     */
    public String getName() {
        return name;
    }

    /**
     Returns the price of the product.
     @return the price of the product
     */
    public double getPrice() {
        return price;
    }

    /**
     Returns the current inventory level of the product.
     @return the current inventory level of the product
     */
    public int getStock() {
        return stock;
    }

    /**
     Returns the minimum inventory level of the product.
     @return the minimum inventory level of the product
     */
    public int getMin() {
        return min;
    }

    /**
     Returns the maximum inventory level of the product.
     @return the maximum inventory level of the product
     */
    public int getMax() {
        return max;
    }

    /**
     Adds a part to the list of associated parts for the product.
     @param part the part to add
     */
    public void addAssociatedPart(Part part) {
        associatedParts.add(part);
    }
    /**

     This method removes the given part from the list of associated parts of the product.
     @param selectedAssociatedPart The part to be removed from the associated parts list.
     @return boolean Returns true if the part was successfully removed from the list, false otherwise.
     */
    public static boolean deleteAssociatedPart(Part selectedAssociatedPart) {
        return associatedParts.remove(selectedAssociatedPart);
    }
    /**

     This method returns an ObservableList containing all the parts associated with the product.
     @return ObservableList<Part> The ObservableList containing all associated parts.
     */
    public ObservableList<Part> getAllAssociatedParts() {
        return associatedParts;
    }
    /**

     This method validates a product's fields and returns an error message if any fields are invalid.

     @param name The name of the product.

     @param min The minimum stock value of the product.

     @param max The maximum stock value of the product.

     @param stock The current stock value of the product.

     @param price The price of the product.

     @param parts The list of parts associated with the product.

     @return String Returns an error message string if any fields are invalid, otherwise returns an empty string.
     */
    public static String isProductValid(String name, int min, int max, int stock, double price, ObservableList<Part> parts) {
        String errorMessage = "";

        if (name == null || name.trim().isEmpty()) {
            errorMessage += "Product name cannot be empty.\n";
        }
        if (min < 0 || max < 0 || stock < 0) {
            errorMessage += "Inventory fields cannot be negative.\n";
        }
        if (min > max) {
            errorMessage += "Min value cannot be greater than Max value.\n";
        }
        if (stock < min || stock > max) {
            errorMessage += "Inventory must be between Min and Max values.\n";
        }
        if (price <= 0) {
            errorMessage += "Price must be greater than zero.\n";
        }
        if (parts.isEmpty()) {
            errorMessage += "Product must have at least one part.\n";
        }

        return errorMessage;
    }

}
