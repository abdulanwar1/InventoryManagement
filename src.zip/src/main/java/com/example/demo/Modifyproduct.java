package com.example.demo;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;
/**

 Controller class for the "Modify Product" screen.
 Allows the user to modify an existing product in the inventory system.
 Implements the Initializable interface to initialize the controller.
 */
public class Modifyproduct implements Initializable {
    private final ObservableList<Part> associatedParts = FXCollections.observableArrayList();
    @FXML
    private TableView<Part> associatedPartsTable;
    public TextField IDField;
    public TextField NameField;
    public TextField InventoryField;
    public TextField PriceField;
    public TextField MinField;
    public TextField MaxField;
    public javafx.scene.control.TableView TableView;
    public TableColumn IDColumn;
    public TableColumn NameColumn;
    public TableColumn InventoryColumn;
    public TableColumn PriceColumn;
    public TextField SearchField;
    public javafx.scene.control.TableView DeleteTableView;
    public TableColumn PartIDColumn;
    public TableColumn PartNameColumn;
    public TableColumn PartInventoryColumn;
    public TableColumn PartPriceColumn;
    public TextField DeleteField;
    private int productIndex;
    @FXML
    private final ObservableList<Part> currentParts = FXCollections.observableArrayList();



    private String errorMessage = "";

    private Product currentProduct;


    private final Product selectedProduct;
    public Modifyproduct(Product selectedProduct) {
        this.selectedProduct = selectedProduct;
    }

    /**

     This method is called when the "Search" button is clicked on the "Modify Product" screen.
     It retrieves the search term entered by the user, searches for matching parts in the Inventory,
     and updates the associated parts table with the search results. If no parts are found,
     an error message is displayed. If the search term is empty, all parts in the Inventory are displayed.
     @param event the event that triggered the method call
     */
    @FXML
    private void SearchPartClick(ActionEvent event) {
        String searchTerm = SearchField.getText().trim().toLowerCase();


        if (searchTerm.isEmpty()) {
            // If the search term is empty, display all parts in the table.
            associatedPartsTable.setItems(Inventory.getAllParts());
        } else {
            // Search for parts by ID or name (partial or full name).
            ObservableList<Part> searchResults = FXCollections.observableArrayList();

            try {
                int partId = Integer.parseInt(searchTerm);
                // Search for parts by ID.
                Part part = Inventory.lookupPart(partId);
                if (part != null) {
                    searchResults.add(part);
                }
            } catch (NumberFormatException e) {
                // Search for parts by name.
                searchResults = Inventory.lookupPart(searchTerm);
            }

            if (searchResults.isEmpty()) {
                // If no parts are found, display an error message.
                Alert alert = new Alert(AlertType.ERROR);
                alert.setTitle("Error");
                alert.setHeaderText("Part not found");
                alert.setContentText("The part you searched for could not be found.");
                alert.showAndWait();
            } else {
                // Highlight or filter the search results.
                TableView.setItems(searchResults);
            }
        }
    }
    /**

     This method is called when the user clicks on the "Add" button in the "Add/Modify Product" screen.
     It adds the currently selected part from the "All Parts" table to the list of associated parts for the selected product.
     If no part is selected, nothing happens.
     The associated parts table is updated with the new list of associated parts for the selected product.
     @param event The ActionEvent object generated when the "Add" button is clicked.
     */
    @FXML
    private void AddClick(ActionEvent event) {
        Part selectedPart = (Part) TableView.getSelectionModel().getSelectedItem();
        if (selectedPart != null) {
            selectedProduct.addAssociatedPart(selectedPart);
            associatedPartsTable.setItems(selectedProduct.getAllAssociatedParts());
        }
    }
    /**

     Handles the delete button click event.

     Removes the selected part from the associated parts list of the current product.

     If the selected part is not associated with the current product, it is removed from the inventory altogether.

     If no part is selected, an error message is displayed.

     Asks for confirmation before deleting the part.
     */
    @FXML
    private void DeleteClick(ActionEvent event) {

        // Get the selected part from the "Current Parts" table view
        Part selectedPart = (Part) DeleteTableView.getSelectionModel().getSelectedItem();
        if (selectedPart == null) {
            // Display an error message if no part is selected
            Alert alert = new Alert(AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText("No Part Selected");
            alert.setContentText("Please select a part to remove.");
            alert.showAndWait();
            return;

        }
        selectedPart = associatedPartsTable.getSelectionModel().getSelectedItem();
        if (selectedPart != null) {
            Alert alert = new Alert(AlertType.CONFIRMATION);
            alert.setTitle("Confirmation");
            alert.setHeaderText("Product Has Associated Parts");
            alert.setContentText("This product has associated parts. Are you sure you want to delete it?");
            Optional<ButtonType> result = alert.showAndWait();
            if (result.get() != ButtonType.OK) {
                // User canceled the delete operation

                Product.deleteAssociatedPart(selectedPart);
                associatedPartsTable.getItems().remove(selectedPart);
            }
        }
        // Ask for confirmation before deleting the part
        Alert confirmAlert = new Alert(AlertType.CONFIRMATION);
        {
            confirmAlert.setTitle("Confirm Deletion");
            confirmAlert.setHeaderText("Are you sure you want to delete this part?");
            confirmAlert.setContentText("This action cannot be undone.");
            Optional<ButtonType> result = confirmAlert.showAndWait();
            if (result.isPresent() && result.get() == ButtonType.OK)
                // Remove the selected part from the "associatedParts" list of the current product
                currentProduct.getAllAssociatedParts().remove(selectedPart);
            // Update the "Current Parts" table view to reflect the changes
            DeleteTableView.setItems(FXCollections.observableArrayList(currentProduct.getAllAssociatedParts()));
            // If necessary, update the "All Parts" table view to show the removed part as available to add to other products
            if (!Inventory.getAllParts().contains(selectedPart)) {
                Inventory.addPart(selectedPart);
            }
        }
    }
    /**

     Handles the event when the "Save" button is clicked on the "Add Product" screen.
     Validates the input fields and either displays an error message or adds the new product to the inventory.
     @param event The action event triggered by clicking the "Save" button.
     @throws IOException If an input/output exception occurs while updating the inventory.
     */
    @FXML
    void SaveButtonClick(ActionEvent event) throws IOException {
        String productName = NameField.getText();
        String productInv = InventoryField.getText();
        String productPrice = PriceField.getText();
        String productMin = MinField.getText();
        String productMax = MaxField.getText();
        try {
            errorMessage = Product.isProductValid(productName, Integer.parseInt(productMin), Integer.parseInt(productMax),
                    Integer.parseInt(productInv), Double.parseDouble(productPrice), associatedParts);
            if (errorMessage.length() > 0) {
                showErrorMessage("Error Adding Product!", "Error!", errorMessage);
            } else {
                Product newProduct = new Product(Integer.parseInt(IDField.getText()), productName,
                        Double.parseDouble(productPrice), Integer.parseInt(productInv),
                        Integer.parseInt(productMin), Integer.parseInt(productMax));
                newProduct.getAllAssociatedParts().addAll(associatedParts);
                Inventory.updateProduct(productIndex, newProduct);

            }
        } catch (NumberFormatException e) {
            showErrorMessage("Error Adding Part", "Error!", "Fields cannot be left blank!");
        }
    }

    /**

     Displays an error message dialog with the specified title, header, and message.
     @param title the title of the error message dialog
     @param header the header of the error message dialog
     @param message the message to display in the error message dialog
     */
    private void showErrorMessage(String title, String header, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(header);
        alert.setContentText(message);
        alert.showAndWait();
    }
    /**

     Handles the "Cancel" button click event to return to the main screen.
     Loads the main screen FXML file, creates a new scene with it, sets the scene to the main stage, and shows the stage.
     @param event The event that triggered this method (i.e. the "Cancel" button click).
     @throws IOException if an input/output exception occurs while loading the FXML file.
     */
    @FXML
    private void CancelClick(ActionEvent event) throws IOException {
        Parent mainScreen = FXMLLoader.load(getClass().getResource("MainScreen.fxml"));
        Scene scene = new Scene(mainScreen);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        window.setScene(scene);
        window.show();
    }

    /**

     Sets the fields and associated parts in the form with the values from the selected product.

     @param product the selected product to be displayed in the form
     */

    public void setProduct(Product product) {
        // Set the fields in the form with the values from the selected product
        IDField.setText(Integer.toString(product.getId()));
        NameField.setText(product.getName());
        InventoryField.setText(Integer.toString(product.getStock()));
        PriceField.setText(Double.toString(product.getPrice()));
        MinField.setText(Integer.toString(product.getMin()));
        MaxField.setText(Integer.toString(product.getMax()));

        // Set the associated parts in the table view
        currentParts.setAll(product.getAllAssociatedParts());
        TableView.setItems(currentParts);
    }



    /**

     Initializes the ModifyProduct class.
     This method sets the initial values for the Modify Product form.
     It sets the values of the fields with the corresponding values of the selected product.
     It sets the columns of the associated parts table view and the modify product add table view.
     It also enables editing for all fields.
     @param url The location used to resolve relative paths for the root object, or null if the location is not known.
     @param resourceBundle The resources used to localize the root object, or null if the root object was not localized.
     */


    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {



        IDField.setText(Integer.toString(selectedProduct.getId()));
        NameField.setText(selectedProduct.getName());
        InventoryField.setText(Integer.toString(selectedProduct.getStock()));
        PriceField.setText(Double.toString(selectedProduct.getPrice()));
        MaxField.setText(Integer.toString(selectedProduct.getMax()));
        MinField.setText(Integer.toString(selectedProduct.getMin()));

        PartIDColumn.setCellValueFactory(new PropertyValueFactory<>("partId"));
        PartNameColumn.setCellValueFactory(new PropertyValueFactory<>("stock"));
        PartInventoryColumn.setCellValueFactory(new PropertyValueFactory<>("Stock"));
        PartPriceColumn.setCellValueFactory(new PropertyValueFactory<>("price"));

        associatedPartsTable.setItems(selectedProduct.getAllAssociatedParts());
        associatedPartsTable.getColumns().setAll(PartIDColumn, PartNameColumn, PartInventoryColumn, PartPriceColumn);
        // Set the columns of the ModifyProductAddTableView to be the same as the associatedPartsTable
        TableView.getColumns().setAll(PartIDColumn, PartNameColumn, PartInventoryColumn, PartPriceColumn);
        IDField.setDisable(true);
        NameField.setEditable(true);
        InventoryField.setEditable(true);
        PriceField.setEditable(true);
        MaxField.setEditable(true);
        MinField.setEditable(true);


    }


}
