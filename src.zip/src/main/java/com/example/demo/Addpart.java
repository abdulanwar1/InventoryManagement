package com.example.demo;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.Alert.AlertType;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;

/**

 This class handles the Add Part form of the inventory management system.

 It allows the user to input details of a new part and add it to the inventory.
 */
public class Addpart implements Initializable {
    private int partID;

    @FXML
    private RadioButton InHouseRBtn;

    @FXML
    private RadioButton OutsourcedRBtn;

    @FXML
    private TextField IDField;

    @FXML
    private TextField NameField;

    @FXML
    private TextField InventoryField;

    @FXML
    private TextField PriceField;

    @FXML
    private TextField MaxField;

    @FXML
    private TextField MinField;

    @FXML
    private TextField DAddField;

    @FXML
    private Label DAddLabel;




    /**

     Updates the dynamic data label to display "Machine ID" when In-House radio button is selected.
     This is an event handler for the InHouseRBtn.
     @param event The ActionEvent that occurred.
     */
    @FXML
    private void InHouseRBtn(ActionEvent event) {
        DAddLabel.setText("Machine ID");
    }
    /**

     Updates the dynamic data label to display "Company Name" when Outsourced radio button is selected.
     This is an event handler for the OutsourcedRBtn.
     @param event The ActionEvent that occurred.
     */

    @FXML
    private void OutsourcedRBtn(ActionEvent event) {
        DAddLabel.setText("Company Name");
    }
    /**

     Generates a new Part ID by finding the highest existing ID in the inventory and adding 1.
     @return The new Part ID.
     */

   /** public int generatePartID() {
        int maxID = 0;
        for (Part part : Inventory.getAllParts()) {
            if (Part.getId() > maxID) {
                maxID = Part.getId();
            }
        }
        return maxID + 1;
    } */
    /**

     Displays a confirmation dialog to the user when they click the "Cancel" button.

     If the user confirms the cancellation, the form is closed and the user is returned to the Main form.

     @param event The ActionEvent that occurred.
     */
    @FXML
    void CancelClick(ActionEvent event) {
        Alert alert = new Alert(AlertType.CONFIRMATION);
        alert.setTitle("Confirm Cancel");
        alert.setHeaderText("Cancel Adding Part");
        alert.setContentText("Are you sure you want to cancel adding the part?");

        Optional<ButtonType> result = alert.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {
            // user clicked OK, go back to the main form
            Parent main = null;
            try {
                main = FXMLLoader.load(getClass().getResource("Mainview.fxml"));
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
            Scene scene = new Scene(main);
            Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
            window.setScene(scene);
            window.show();
        }
    }
    /**

     Saves the newly created part by retrieving the input values, creating a new Part object,

     adding it to the inventory, and navigating back to the main form.

     @param event the ActionEvent triggered by the Save button click
     */
    @FXML
    private void SaveClick(ActionEvent event) {
        // Get the values from the input fields
        try {
            String name = NameField.getText();

            int inv = Integer.parseInt(InventoryField.getText());
            double price = Double.parseDouble(PriceField.getText());
            int max = Integer.parseInt(MaxField.getText());
            int min = Integer.parseInt(MinField.getText());
            String dyn = DAddField.getText();

            // Create a new part object based on the radio button selection
            Part newPart;
            if (InHouseRBtn.isSelected()) {
                int machineId = Integer.parseInt(dyn);
                newPart = new InHouse(0, name, price, inv, min, max, machineId);
            } else {
                String companyName = dyn;
                newPart = new Outsourced(0, name, price, inv, min, max, companyName);
            }

            // Add the new part to the inventory
            Inventory.addPart(newPart);

            // Go back to the main form





            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/demo/Mainview.fxml"));
            Parent parent = loader.load();
            Scene scene = new Scene(parent);
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();

            stage.setScene(scene);
            stage.show();
        }
        catch(Exception e){
            System.out.println(e.getMessage());
        }
    }
    /**

     Initializes the form by setting the initial radio button selection, label text, and generating a new ID for the part.

     @param url the location used to resolve relative paths for the root object, or null if the location is not known

     @param resourceBundle the resource bundle used to localize the root object, or null if the root object was not localized
     */

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        // Set initial radio button selection
        int partID = (int) (Math.random() * 100);
        InHouseRBtn.setSelected(true);
        OutsourcedRBtn.setSelected(false);
        DAddLabel.setText("Machine ID");
       // partID = Inventory.generatePartID();
       // generatePartID.setText("AUTO GEN: " + partID);
        // Generate a new ID for the part
       // int newPartID = generatePartID();
      //  IDField.setText(Integer.toString(newPartID));

    }
}
