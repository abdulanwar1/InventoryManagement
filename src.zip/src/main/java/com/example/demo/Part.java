package com.example.demo;
 /**
 * Supplied class Part.java
 */

/**
 * Class provided by WGU
 *
 * @author Place Your Name Here
 */
public abstract class Part {
    private static int id;
    private static String name;
    private static double price;
    private static int stock;
    private static int min;
    private static int max;

    public Part(int id, String name, double price, int stock, int min, int max) {
        Part.id = id;
        Part.name = name;
        Part.price = price;
        Part.stock = stock;
        Part.min = min;
        Part.max = max;
    }

    /**
     * @return the id
     */
    public static int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        Part.id = id;
    }

    /**
     * @return the name
     */
    public static String getName() {
        return name;
    }

    /**
     * @param name the name to set
     */
    public void setName(String name) {
        Part.name = name;
    }

    /**
     * @return the price
     */
    public static double getPrice() {
        return price;
    }

    /**
     * @param price the price to set
     */
    public void setPrice(double price) {
        Part.price = price;
    }

    /**
     * @return the stock
     */
    public static int getStock() {
        return stock;
    }

    /**
     * @param stock the stock to set
     */
    public void setStock(int stock) {
        Part.stock = stock;
    }

    /**
     * @return the min
     */
    public static int getMin() {
        return min;
    }

    /**
     * @param min the min to set
     */
    public void setMin(int min) {
        Part.min = min;
    }

    /**
     * @return the max
     */
    public static int getMax() {
        return max;
    }

    /**
     * @param max the max to set
     */
    public void setMax(int max) {
        Part.max = max;
    }

}