package com.example.demo;


import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
/**

 This class represents the Modify Part form controller, responsible for managing the user interface

 for modifying an existing part in the inventory management system. It implements the Initializable interface

 to initialize the form and handles events such as button clicks and radio button selections.
 */
public class Modifypart implements Initializable {

    public RadioButton InHouseRBtn;
    public RadioButton OutsourcedRBtn;
    public Label DModifyLabel;
    public TextField IDField;
    public TextField NameField;
    public TextField InventoryField;
    public TextField PriceField;
    public TextField MinField;
    public TextField MaxField;
    public TextField DField;
    private boolean isInHouse;
    private final Part selectedPart;

    /**

     Constructs a new Modifypart object with the specified part to be modified.
     @param selectedPart the part to be modified
     */
    public Modifypart(Part selectedPart) {
        this.selectedPart = selectedPart;
    }


    /**

     Handles the In-House radio button selection by changing the label text and setting isInHouse to true.
     @param event the event that occurred
     */

    @FXML
    private void InHouseRBtn(ActionEvent event) {
        DModifyLabel.setText("Machine ID");
        isInHouse = true;
    }

    /**

     Handles the Outsourced radio button selection by changing the label text and setting isInHouse to false.
     @param event the event that occurred
     */
    @FXML
    private void OutsourcedRBtn(ActionEvent event) {
        DModifyLabel.setText("Company Name");
        isInHouse = false;
    }
    /**
     * Saves the modifications made to the selected part by creating a new Part object with the new data
     * and updating it in the Inventory, then closes the Modify Part window.
     *
     * @param event the ActionEvent representing the clicking of the Save button
     */
    @FXML
    private void SaveClick(ActionEvent event) {
        int id = Integer.parseInt(IDField.getText());
        String name = NameField.getText();
        int stock = Integer.parseInt(InventoryField.getText());
        double price = Double.parseDouble(PriceField.getText());
        int min = Integer.parseInt(MinField.getText());
        int max = Integer.parseInt(MaxField.getText());
        Part newPart;
        if (isInHouse) {
            int machineId = Integer.parseInt(DField.getText());
            newPart = new InHouse(id, name, price, stock, min, max, machineId);
        } else {
            String companyName = DField.getText();
            newPart = new Outsourced(id, name, price, stock, min, max, companyName);
        }
        Inventory.updatePart(Inventory.getAllParts().indexOf(selectedPart), newPart);
        Stage stage = (Stage) IDField.getScene().getWindow();
        stage.close();
    }

    /**
     * Closes the Modify Part window without saving any changes.
     *
     * @param event the ActionEvent representing the clicking of the Cancel button
     * @throws IOException if an I/O error occurs while closing the window
     */
    @FXML
    private void CancelClick(ActionEvent event) throws IOException {
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.close();

    }
    /**

     Initializes the form with the data of the selected part and sets the appropriate radio button selection.

     @param url the location used to resolve relative paths for the root object, or null if the location is not known.

     @param resourceBundle the resource bundle used to localize the root object, or null if the root object was not localized.
     */


    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {


        IDField.setText(String.valueOf(Part.getId()));
        NameField.setText(Part.getName());
        InventoryField.setText(String.valueOf(Part.getStock()));
        PriceField.setText(String.valueOf(Part.getPrice()));
        MaxField.setText(String.valueOf(Part.getMax()));
        MinField.setText(String.valueOf(Part.getMin()));

        if (selectedPart instanceof InHouse) {
            InHouseRBtn.setSelected(true);
            DField.setText(String.valueOf(((InHouse) selectedPart).getMachineId()));
            DModifyLabel.setText("Machine ID");
            isInHouse = true;
        } else if (selectedPart instanceof Outsourced) {
            OutsourcedRBtn.setSelected(true);
            DField.setText(((Outsourced) selectedPart).getCompanyName());
            DModifyLabel.setText("Company Name");
            isInHouse = false;
        }

    }
}