package com.example.demo;
/**

 A subclass of the Part class representing parts made by an external company.
 */
public class Outsourced extends Part {

    private String companyName;

    /**
     Constructs an Outsourced object with the specified values.
     @param id the ID of the part
     @param name the name of the part
     @param price the price of the part
     @param stock the inventory level of the part
     @param min the minimum inventory level of the part
     @param max the maximum inventory level of the part
     @param companyName the name of the company that made the part
     */
    public Outsourced(int id, String name, double price, int stock, int min, int max, String companyName) {
        super(id, name, price, stock, min, max);
        this.companyName = companyName;
    }

    /**
     Returns the name of the company that made the part.
     @return the name of the company that made the part
     */
    public String getCompanyName() {
        return companyName;
    }

    /**
     Sets the name of the company that made the part.
     @param companyName the name of the company that made the part
     */
    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }
}